<?php
include "../db.php";
$obj = new database();
$id = $_GET['id'];

$tbl = 'career';
$con = "id = '$id'";
$obj->delete_data($tbl , $con);
?>
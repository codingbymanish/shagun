<?php
include "../db.php";
$obj = new database();
$id = $_GET['id'];

$tbl = 'contactus';
$con = "id = '$id'";
$obj->delete_data($tbl , $con);
header("location:table.php");

?>
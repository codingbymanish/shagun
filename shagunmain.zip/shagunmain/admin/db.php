<?php

class database
{
    private $db_host = "localhost";
    private $db_user = "root";
    private $db_pass = "";
    private $db_name = "shagun";

    private $mysqli = "";
    private $result = array();
    private $con = false;

    public function __construct()
    {
        $this->mysqli = new mysqli($this->db_host, $this->db_user, $this->db_pass, $this->db_name);
        $this->con = true;
    }

    // public function insert_data($tbl_name, $param = array())
    // {
    //     $tbl_column = implode(",", array_keys($param));
    //     $tbl_values = implode("','", $param);

    //     $sql = "INSERT INTO $tbl_name ($tbl_column) VALUES ('$tbl_values')";
    //     //  exit();

    //     if ($this->mysqli->query($sql)) {
    //         array_push($this->result, $this->mysqli->insert_id);
    //     }
    // }


    public function insert_data($tbl_name, $param = array(), $img = null)
    {
        if ($img != null) {
            $tbl_column = implode(",", array_keys($param));
            $tbl_values = implode("','", $param);
            $img_path = "../img/" . $img;
            $sql = "INSERT INTO $tbl_name ($tbl_column ,`img`) VALUES ('$tbl_values' , '$img_path')";
            //  exit();
            move_uploaded_file($_FILES["img"]['tmp_name'], $img_path);
            if ($this->mysqli->query($sql)) {
                array_push($this->result, $this->mysqli->insert_id);
            }
        } else {
            $tbl_column = implode(",", array_keys($param));
            $tbl_values = implode("','", $param);

            $sql = "INSERT INTO $tbl_name ($tbl_column) VALUES ('$tbl_values')";
            //  exit();

            if ($this->mysqli->query($sql)) {
                array_push($this->result, $this->mysqli->insert_id);
            }
        }
    }
    public function insert_img($tbl_name, $img)
    {

        $img_path = "../img/".$img;
        $sql = "INSERT INTO $tbl_name (`img`) VALUES ('$img_path')";
     
        move_uploaded_file($_FILES["img"]['tmp_name'], $img_path);
        if ($this->mysqli->query($sql)) {
            array_push($this->result, $this->mysqli->insert_id);
        }
    }

    public function update_img($tbl, $cond, $img )
    {


         
            $img_path = "../img/" . $img;

            $sql = "UPDATE $tbl SET `img`='$img_path' WHERE $cond";
            $query = $this->mysqli->query($sql);
            if ($query) {
                array_push($this->result, $this->mysqli->affected_rows);
                move_uploaded_file($_FILES["img"]['tmp_name'], $img_path);
            }
       
    }
    public function select_data($tbl, $cond = null)
    {

        $sql = "SELECT * FROM $tbl ";

        if ($cond != null) {
            $sql .= " WHERE $cond";
        }
        $query = $this->mysqli->query($sql);
        if ($query) {
            $this->result = $query->fetch_all(MYSQLI_ASSOC);
            // array_push($this->result, $this->mysqli->affected_rows);
        }
    }


  


    // public function update_data($tbl, $param =  array(), $cond)
    // {


    //     $set =  implode(',', array_map(function ($key, $value) {
    //         return "$key = '$value'";
    //     }, array_keys($param), $param));

    //     $sql = "UPDATE $tbl SET $set WHERE $cond";
    //     $query = $this->mysqli->query($sql);
    //     if ($query) {
    //         array_push($this->result, $this->mysqli->affected_rows);
    //     }
    // }


    public function update_data($tbl, $param =  array(), $cond, $img = null)
    {

        if ($img != null) {
            $set =  implode(',', array_map(function ($key, $value) {
                return "$key = '$value'";
            }, array_keys($param), $param));
            $img_path = "../img/" . $img;

            $sql = "UPDATE $tbl SET $set, `img`='$img_path' WHERE $cond";
            $query = $this->mysqli->query($sql);
            if ($query) {
                array_push($this->result, $this->mysqli->affected_rows);
                move_uploaded_file($_FILES["img"]['tmp_name'], $img_path);
            }
        } else {
            $set =  implode(',', array_map(function ($key, $value) {
                return "$key = '$value'";
            }, array_keys($param), $param));

            $sql = "UPDATE $tbl SET $set WHERE $cond";
            $query = $this->mysqli->query($sql);
            if ($query) {
                array_push($this->result, $this->mysqli->affected_rows);
            }
        }
    }
    public function delete_data($tbl, $cond)
    {

        $sql = "DELETE FROM $tbl  WHERE $cond";
        $query = $this->mysqli->query($sql);
        if ($query) {
            header("location:table.php");
        }
    }





    public function getResult()
    {
        $val = $this->result;
        $this->result = array();
        return $val;
    }
}

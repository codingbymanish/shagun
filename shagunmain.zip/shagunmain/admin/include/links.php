<link rel="stylesheet" href="./bootstrap/bootstrap.min.css">
<script src="bootstrap/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
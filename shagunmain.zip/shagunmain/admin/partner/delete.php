<?php
include "../db.php";
$obj = new database();
$id = $_GET['id'];

$tbl = 'partner';
$con = "id = '$id'";
$obj->delete_data($tbl , $con);
?>
<?php
include "../db.php";
$obj = new database();
$id = $_GET['id'];

$tbl = 'video';
$con = "id = '$id'";
$obj->delete_data($tbl , $con);
?>
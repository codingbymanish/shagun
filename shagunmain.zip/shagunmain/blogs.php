<?php
include "db.php";
$obj = new database();


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include "include/link.php" ?>
</head>
<body>
<?php include "include/nav.php" ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-8 text-center">
            <h3>Blogs</h2>
            <h2>The Perfect Gift for a Sparkling Home</h2>
            <p>By admin on February 3, 2023</p>
            <img src="./allimages/pexels-matilda-wormwood-4099467.jpg" width="100%" alt="">
            <p>We all know a person in our circle who is very fond of keeping everything clean and tidy. They hate to see the mess around whether it is in their home or any other home that they visit. So, whenever you are planning to gift them something, it can be…</p>
        </div>


        <div class="col-lg-8 text-center mt-4">
    
            <h2>Important Things To Consider While Purchasing Cleaning Products In The New Year</h2>
            <p>By admin on February 3, 2023</p>
            <img src="./allimages/pexels-pixabay-48889.jpg" width="100%" alt="">
            <p>We all know a person in our circle who is very fond of keeping everything clean and tidy. They hate to see the mess around whether it is in their home or any other home that they visit. So, whenever you are planning to gift them something, it can be…</p>
        </div>
    </div>
</div>    


<?php include "include/footer.php" ?>

</body>
</html>
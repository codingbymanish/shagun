<?php
include "./db.php";
$obj = new database();

if(isset($_POST['submit'])){
    $tbl_name = 'career';
    $param = [
        'fname'=>$_POST['fname'],
        'contact'=>$_POST['contact'],
        'ref'=>$_POST['ref'],
        'lname'=>$_POST['lname'],
        'email'=>$_POST['email'],
        'experience'=>$_POST['experience'],
        'bio'=>$_POST['bio'],
    ];
    $obj->insert_data($tbl_name, $param);
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include "include/link.php" ?>
</head>

<body>
    <?php include "include/nav.php" ?>


    <div class="container mt-5 mb-4">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center">
                <h4>Work With Us</h4>
                <p>No Further, Shagun a trusted household cleaning products company, Is Looking out for Young, Dynamic, Passion Driven and Result Oriented Individual to Drive and Scale its Mission and Vision.</p>

                <form action="" method="post">

                    <div class="row">
                        <div class="col-lg-6">
                            <input type="text" name="fname" id="" placeholder="First name" class="form-control mt-4">
                            <input type="text" name="contact" id="" placeholder="Contact Number" class="form-control mt-4">
                            <input type="text" name="ref" id="" placeholder="Ref By" class="form-control mt-4">
                        </div>
                        <div class="col-lg-6">
                            <input type="text" name="lname" id="" placeholder="Last name" class="form-control mt-4">
                            <input type="text" name="email" id="" placeholder="Your Email address" class="form-control mt-4">
                            <input type="text" name="experience" id="" placeholder="Year of Experience" class="form-control mt-4">
                        </div>
                    </div>

                    <input type="file" name="bio" id="" class="form-control mt-4">
                    <input type="submit" name="submit" class="text-white mt-4" id="" value="Apply Now" style="height:50px ; width:130px;    background: linear-gradient(#3F7BBC, #2C6EB6, #135DAD);
    
    border-radius: 5px;
    border: 1px solid #0088CC;">
                </form>
            </div>
        </div>
    </div>

    <?php include "include/footer.php" ?>

</body>

</html>
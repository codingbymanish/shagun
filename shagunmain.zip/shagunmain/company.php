<?php
include "db.php";
$obj = new database();



?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include "include/link.php" ?>
</head>

<body>
    <?php include "include/nav.php" ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <img src="./allimages/Gebi-Factory-Image.jpg" width="100%" alt="">
            </div>
        </div>
    </div>

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="container">
                    <div class="row mt-5">
                        
                  
            <div class="col-lg-6">
                <h1>Video</h1>
            </div>
            <div class="col-lg-6">
                <h1>
                    About us
                </h1>
                <p>A form Commitment to quality product innovation and answering determination has rewarded & SHAGUN the brand name & Raj Cleanwel Exim. Pvt. Ltd a substation growth and unparalleled name in the scrubbers & clean well wiper industry in India. Today with our vast industrial expertise and consistent effort, we have expended and business to remarkable larger market Base and have become one of the leading manufacturers in the Concerned Industry. </p>
                <p>Working on the principles of international quality standards, we have established a brand image and mark visibility in the Word. As a good oriental Company. </p>
                <p>We lead the market by our Extensive products and Price range. Our company is based on “Customer First” spirit. </p>
                <p>To find a good partner is not easy but we are sure <strong>SHAGUN</strong> is the best one in the field of cleaning items and no doubt your best choice. Quality Assurance We always maintain superior and rigidly quality control procedures in the manufacturing of our products. A quality Central department and testing facilities, is the biggest asset of the company. Every team is thoroughly inspected before the Final packaging so as to ensure that only the best products will reach the hands of our valued clients. </p>
                <p>We have advanced equipment and prefect management and have gained years of experience in manufacturing and expanded sales net work.. </p>
                <p>To bring forth the most modern and perfect products to people is our aim, and also our motive fore sources. Our eyes are on the world and aim at the future</p>
                <strong>Our Strength</strong>
                <p>We are well-versed with the trends prevailing in the industry and hence we have sophisticated machines for manufacturing the best assortment of cleaning products Our ability to feed back orders with in tight deadlines has provided us a leading edge in the industry and has helped us attains remarkable position in the present competitive Markets. We attribute our phenomenal success to the continuous dedication and efforts of our experienced staff. We believe in Continual trend setting by offering innovative products, hence our team keeps on researching the changing market trends and Conditions to bring effective and high performance products to our valued clients.</p>
            </div>
            </div>
                </div>
            </div>
        </div>
    </div>

    <?php include "include/footer.php" ?>

</body>

</html>
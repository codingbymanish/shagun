<?php
include "./db.php";
$obj = new database();

if(isset($_POST['submit'])){
    $tbl_name = 'contactus';
    $param = [
        'name'=>$_POST['name'],
        'number'=>$_POST['number'],
        'email'=>$_POST['email'],
        'address'=>$_POST['address'],
        'message'=>$_POST['message'],
    ];
    $obj->insert_data($tbl_name, $param);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include "include/link.php" ?>
</head>

<body>
    <?php include "include/nav.php" ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="container">
                    <div class="row mt-5 mb-5">
                        <div class="col-lg-6">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3500.508540153464!2d77.15889187929432!3d28.67443061939217!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d025b3c8c29cf%3A0xd4166195ff0b0af5!2s974%2F64%2C%20Deva%20Ram%20Park%2C%20Lekhu%20Nagar%2C%20Tri%20Nagar%2C%20Delhi%2C%20110035!5e0!3m2!1sen!2sin!4v1712052418168!5m2!1sen!2sin" width="100%" height="500" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                        <div class="col-lg-6">
                            <h2>Contact Us</h2>
                            <p>Dear visitor,
                                <br>
                                Please provide a few essential details, including all the fields marked *. then click the "SUBMIT ENQUIRY" button. You will receive an email confarmation of you ,message and we will contact you as soon as possible to respond to your enquiry.

                            </p>
                            <p><strong>Company Name : RAJ CLEANWEL EXIM PVT. LTD.
                                    <br>
                                    Contact Person : Mr. Rajesh Khetan ( Managing Director)

                                </strong></p>
                            <p>974/64, Lekhu Nagar, Tri Nagar, New Delhi - 110035 <br>
                                +91- 7838646660/62/63, 011-35007312/13/14/15 <br>
                                info@shaguncleaning.com, raj@shaguncleaning.com salesshagun1@gmail.com</p>

                            <form action="" method="post" style="background-color: rgb(235,239,245);">

                                <div class="row p-3">
                                    <div class="col-lg-6">
                                        <input type="name" name="name" id="" placeholder="Enter Your Name*" class="form-control mt-2">
                                        <input type="number" name="number" id="" placeholder="Enter Your Mobile No*" class="form-control  mt-2">
                                    </div>
                                    <div class="col-lg-6">
                                        <input type="email" name="email" id="" placeholder="Enter Your Email*" class="form-control mt-2">
                                        <input type="text" name="address" id="" placeholder="Enter Your Address*" class="form-control mt-2">
                                    </div>
                                    <div class="col-lg-12">

                                        <input type="text " name="message" id="" class="form-control mt-2" placeholder="Message*">
                                        <input type="submit" name="submit" id="" class="mt-2" style="    background-color: #E77817;    padding: 8px 20px;   color: white;border: 0px; border-radius: 5px;">
                                    </div>

                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <?php include "include/footer.php" ?>

</body>

</html>
<?php

class database
{
    private $db_host = "localhost";
    private $db_user = "root";
    private $db_pass = "";
    private $db_name = "shagun";

    private $mysqli = "";
    private $result = array();
    private $con = false;

    public function __construct()
    {
        $this->mysqli = new mysqli($this->db_host, $this->db_user, $this->db_pass, $this->db_name);
        $this->con = true;
    }

    public function insert_data($tbl_name, $param = array())
    {
        $tbl_column = implode(",", array_keys($param));
        $tbl_values = implode("','", $param);

        $sql = "INSERT INTO $tbl_name ($tbl_column) VALUES ('$tbl_values')";
        //  exit();

        if ($this->mysqli->query($sql)) {
            array_push($this->result, $this->mysqli->insert_id);
        }
    }


    public function select_data($tbl, $cond = null)
    {

        $sql = "SELECT * FROM $tbl ";

        if ($cond != null) {
            $sql .= " WHERE $cond";
        }
        $query = $this->mysqli->query($sql);
        if ($query) {
            $this->result = $query->fetch_all(MYSQLI_ASSOC);
            // array_push($this->result, $this->mysqli->affected_rows);
        }
    }



    public function update_data($tbl, $param =  array(), $cond)
    {


        $set =  implode(',', array_map(function ($key, $value) {
            return "$key = '$value'";
        }, array_keys($param), $param));

        $sql = "UPDATE $tbl SET $set WHERE $cond";
        $query = $this->mysqli->query($sql);
        if ($query) {
            array_push($this->result, $this->mysqli->affected_rows);
        }
    }
public function delete_data($tbl, $cond){

        $sql = "DELETE FROM $tbl  WHERE $cond";
        $query = $this->mysqli->query($sql);
        if ($query) {
        header("location:table.php");
           
        }
}





    public function getResult()
    {
        $val = $this->result;
        $this->result = array();
        return $val;
    }
}

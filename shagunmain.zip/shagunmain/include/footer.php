

    <div class="container-fluid border   border-3 border-start-0     border-end-0">
        <div class="row">
            <div class="col-lg-12">


                <div class="container">
                    <div class="row mt-5 mb-3">
                        <div class="col-lg-3 ">
                            <h5>USEFUL LINKS</h5>
                            <ul class="list-unstyled">
                                <li class="mt-2"><a href="" class="text-decoration-none text-dark " >Home</a></li>
                                <li class="mt-2"><a href="" class="text-decoration-none text-dark " >About Us</a></li>
                                <li class="mt-2"><a href="" class="text-decoration-none text-dark " >All Categories</a></li>
                                <li class="mt-2"><a href="" class="text-decoration-none text-dark " >Gallery</a></li>
                                <li class="mt-2"><a href="" class="text-decoration-none text-dark " >Contact Us</a></li>
                            </ul>

                        </div>

                        <div class="col-lg-3">
                            <h5>TOP CATEGORY</h5>
                            <ul class="list-unstyled">
                                <li class="mt-2"><a href="" class="text-decoration-none text-dark " >Brushes</a></li>
                                <li class="mt-2"><a href="" class="text-decoration-none text-dark " >Dish Cloth cleaning Pad</a></li>
                                <li class="mt-2"><a href="" class="text-decoration-none text-dark " >Wipers</a></li>
                                <li class="mt-2"><a href="" class="text-decoration-none text-dark " >Daily Need Product</a></li>
                                <li class="mt-2"><a href="" class="text-decoration-none text-dark " >Floor Cleaning Cloth (Pochha)</a></li>
                                <li class="mt-2"><a href="" class="text-decoration-none text-dark " >Green Scrubber</a></li>
                            </ul>
                        </div>

                        <div class="col-lg-3">
                            <h5>TOP PRODUCTS    </h5>
                            <ul class="list-unstyled">
                                <li class="mt-2"><a href="" class="text-decoration-none text-dark " >Tiles Brush (S-23)
                                </a></li>
                                <li class="mt-2"><a href="" class="text-decoration-none text-dark " >Clip & Fit Cotton Mop 9", Pipe 4 Feet PVC</a></li>
                                <li class="mt-2"><a href="" class="text-decoration-none text-dark " >Cotted (S-47)
                                </a></li>
                                <li class="mt-2"><a href="" class="text-decoration-none text-dark " >STICK BROOM KHARATA (S-32)</a></li>
                                <li class="mt-2"><a href="" class="text-decoration-none text-dark " >J-20 Steel Scrubber
                                </a></li>
                                <li class="mt-2"><a href="" class="text-decoration-none text-dark " >Toilet Brush (ST-108)</a></li>
                                <li class="mt-2"><a href="" class="text-decoration-none text-dark " >Floor Wiper SW 107
                                </a></li>
                            </ul>
                        </div>
                        <div class="col-lg-3">
                            <h5> ABOUT US    </h5>
                            <ul class="list-unstyled">
                                <li class="mt-2"> <i class="fa-solid fa-location-dot " style="color: black;"></i><a href="" class="text-decoration-none text-dark " > 974/64, Lekhu Nagar, Tri Nagar
                                </a></li>
                                <li class="mt-2"><a href="" class="text-decoration-none text-dark " > Mob. - +91- 7838646660
                                </a></li>
                                <li class="mt-2"><a href="" class="text-decoration-none text-dark " > Support - info@shaguncleaning.com

                                <li class="mt-2 text-start"><img src="./allimages/logo.png" alt="" width="100%"></li>
                              
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 py-3">
                            <p>Copyright © 2022, Designed And Maintained By <a href="" class="text-decoration-none">Hedkey India Pvt Ltd.</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

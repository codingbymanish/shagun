<div class="container-fluid" style="background-color: rgb(45,204,211);">
    <div class="row">
        <div class="col-lg-12">
            <div class="container">
                <div class="col-lg-12 py-2 ">
                    <a href=""><i class="fa-brands   fa-facebook-f" style="color: white;"></i></a>
                    <a href=""><i class="fa-brands  ms-2 fa-linkedin-in" style="color: white;"></i></a>
                    <a href=""><i class="fa-brands  ms-2 fa-twitter" style="color: white;"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <nav class="navbar navbar-expand-lg bg-body-tertiary">
                            <div class="container-fluid">

                                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                    <span class="navbar-toggler-icon"></span>
                                </button>
                                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                                        <li class="nav-item">
                                            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" role="button" data-bs-toggle="dropdown" aria-expanded="false">Products</a>
                                            <ul class="dropdown-menu " style="width: 100%;">

                                                <div class="container  ">
                                                    <div class="row" style="width: 100%;">
                                                        <!-- <div class="col-lg-12"> -->
                                                            <?php
                                                            //  include "../db.php";
                                                            $obj = new database();
                                                            $tbl = 'product';
                                                            $obj->select_data($tbl);


                                                            ?>
                                                            <?php
                                                            $arr =  $obj->getResult();

                                                            foreach ($arr as $value => $v) { ?>
                                                              <div class="col-lg-3">
                                                                  <div class="item">
                                                                    <div class="card text-center border-0">
                                                                        <div class="img-card text-center">
                                                                            <img src="./admin/img/<?php echo $v['img'] ?>" alt="" width="50%" class="rounded-3">

                                                                        </div>
                                                                        <div class="card-footer border-0">
                                                                            <button class="btn  text-dark w-75" ><?php echo $v['data'] ?></button>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                              </div>
                                                            <?php } ?>


                                                        <!-- </div> -->
                                                    </div>
                                                </div>



                                            </ul>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="partner.php">Become our Partner</a>
                                        </li>
                                        <li class="nav-item dropdown">
                                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">

                                                Knowledge Center
                                            </a>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="blogs.php">Blogs</a></li>
                                                <li><a class="dropdown-item" href="video.php">Video</a></li>

                                            </ul>
                                        </li>

                                        <li class="nav-item dropdown">
                                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">

                                                About Us
                                            </a>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="company.php">Company</a></li>
                                                <li><a class="dropdown-item" href="career.php">Career</a></li>
                                                <li><a class="dropdown-item" href="contactus.php">Contact Us</a></li>

                                            </ul>
                                        </li>
                                    </ul>

                                </div>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
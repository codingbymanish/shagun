<?php
include "db.php";
$obj = new database();
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <?php include "include/link.php" ;?>
   <style>
    
    .cardimg:hover {
      transform: scale(1.1);
      transition: 0.5s;
    }

    .cardimg {
      transition: 0.5s;


    }

    .box {
      background-color: rgba(0, 0, 0, 0.572);
      position: absolute;
      width: 76%;
      height: 200px;
      top: 50%;
      left: 50%;
      margin: -38%;
      display: grid;
      place-items: center;
    }

    .catbtn {
      background: linear-gradient(#3F7BBC, #2C6EB6, #135DAD);
      padding: 16px 25px;
      border-radius: 5px;
      border: 1px solid #0088CC;
    }

    .cardbtn {
      padding: 9px 25px;
      text-align: center;
      border: 2px solid #1E73BE;
      transition: 0.5s;
      font-weight: 500;
    }

    #owlfirst .owl-nav button span {
      display: none;
    }
  </style>
</head>

<body>
  <?php include "include/nav.php"; ?>


  <div class="container-fluid">
    <div class="row ">
      <div class="col-lg-12 g-0">
        <div id="carouselExample" class="carousel slide">
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img src="./allimages/1.jpg" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
              <img src="./allimages/2.jpg" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
              <img src="./allimages/3.jpg" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
              <img src="./allimages/4.jpg" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
              <img src="./allimages/5.jpg" class="d-block w-100" alt="...">
            </div>
          </div>
          <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>
        </div>
      </div>
    </div>
  </div>


  <div class="container">
    <div class="row ">
      <div class="col-lg-3 mt-5 ">
        <div class="card rounded-0">
          <div class="card-img" style=" overflow: hidden;">
            <img src="./allimages/broom.png" width="100%" alt="" class="cardimg">

          </div>

          <div class="box p-2 text-center  rounded-3   text-white">
            <h3>Natural & Dustfee Broom</h3>
            <a href="" class="btn text-dark w-50 mt-2 bg-white">View</a>
          </div>
        </div>
      </div>





      <div class="col-lg-3 mt-5 ">
        <div class="card rounded-0">
          <div class="card-img" style=" overflow: hidden;">
            <img src="./allimages/wiper.png" width="100%" alt="" class="cardimg">

          </div>

          <div class="box p-2 text-center  rounded-3   text-white">
            <h3>Floor Wipers</h3>
            <a href="" class="btn text-dark w-50 mt-2 bg-white">View</a>
          </div>
        </div>
      </div>


      <div class="col-lg-3 mt-5 ">
        <div class="card rounded-0">
          <div class="card-img" style=" overflow: hidden;">
            <img src="./allimages/steel-scrub.png" width="100%" alt="" class="cardimg">

          </div>

          <div class="box p-2 text-center  rounded-3   text-white">
            <h3>Utensil Scrubbers</h3>
            <a href="" class="btn text-dark w-50 mt-2 bg-white">View</a>
          </div>
        </div>
      </div>


      <div class="col-lg-3 mt-5 ">
        <div class="card rounded-0">
          <div class="card-img" style=" overflow: hidden;">
            <img src="./allimages/mop1.png" width="100%" alt="" class="cardimg">

          </div>

          <div class="box p-2 text-center  rounded-3 text-white">
            <h3>Mops</h3>
            <a href="" class="btn text-dark w-50 mt-2 bg-white">View</a>
          </div>
        </div>
      </div>




    </div>
  </div>


  <div class="container">
    <div class="row mt-5">
      <?php
      // include "db.php";
      // $obj = new database();

      $tbl = 'product';

      $obj->select_data($tbl);

      ?>

      <h3 class="text-center mt-5">Product Photos</h3>

      <div class="col-lg-12 mt-5">
        <div class="owl-carousel " id="owlfirst">
          <?php
          $arr =  $obj->getResult();

          foreach ($arr as $value => $v) { ?>
            <div class="item" >
              <div class="card text-center shadow">
                <div class="img-card text-center" >
                  <img src="./admin/img/<?php echo $v['img'] ?>" alt="" class="rounded-3" style="aspect-ratio: 2/2 ; object-fit:contain;">

                </div>
                <div class="card-footer border-0">
                  <button class="btn  text-white w-75" style="background:rgba(0, 0, 0, 0.619);"><?php echo $v['data'] ?></button>
                </div>
              </div>

            </div>
          <?php } ?>


        </div>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="row">
      <div class="col-lg-12 text-center mt-5">
        <h3 class=" text-center">
          Catalogue & Brochure
        </h3>
      </div>

      <div class="col-lg-6 text-center mt-5">

        <a class="btn catbtn  text-decoration-none text-white"><i class="fa-solid fa-file-pdf"></i> Tri Fold Catalogue</a>
      </div>
      <div class="col-lg-6 text-center mt-5">
        <a class="btn catbtn  text-decoration-none text-white"><i class="fa-solid fa-file-pdf"></i> Shagun Brochure</a>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="row">
      <div class="col-lg-12 mt-5 text-center">
        <h3>Our Trending Products</h3>
      </div>
      <?php
      // include "db.php";
      // $obj = new database();
      $tbl = 'card';
      $obj->select_data($tbl);
      ?>

<img src="images/ESICJPEG1.webp" alt="1" width="80%" loading="lazy" style="aspect-ratio: 4/2 ; object-fit:contain;">
      <?php
      $arr =  $obj->getResult();
      foreach ($arr as $value => $v) { ?>
        <div class="col-lg-3 mt-5">
          <div class="card border-0">
            <div class="card-img text-center">
              <img src="./admin/img/<?php echo $v['img'] ?>" class="cardimg" style="height: 250px; object-fit: contain;" alt="">
            </div>
            <div class="card-footer text-center border-0">
              <p class="text-center"><?php echo $v['data'] ?></p>
              <a href="" class="cardbtn   text-decoration-none rounded"> View Details</a>
            </div>
          </div>
        </div>
      <?php } ?>
    </div>
  </div>
  </div>

  <div class="container">

    <?php
    // include "../shagun/db.php";
    $obj = new database();

    $tbl = 'partner';

    $obj->select_data($tbl);


    ?>
    <div class="row mb-3">
      <h4 class="text-center mt-5">Our Clients & Partnerships</h4>


      <?php
      $arr =  $obj->getResult();

      foreach ($arr as $value => $v) { ?>


        <div class="col-lg-3 col-md-6  my-2 d-flex   justify-content-center  text-center  ">

          <div class="shadow text-center   p-3 " style="width: 200px;
    height: 200px;
    object-fit: contain;
    display: grid;
    place-items: center;">
            <img src="./admin/img/<?php echo $v['img']; ?>" width="100%" alt="">
          </div>
        </div>


      <?php } ?>
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script src="owl.js"></script>
  <script src="main.js"></script>

  <script>
    $('#owlfirst').owlCarousel({
      loop: true,
      margin: 10,
      responsiveClass: true,
      autoplayTimeout: 3000,
      autoplay: true,
      responsive: {
        0: {
          items: 1,
          nav: true
        },
        600: {
          items: 3,
          nav: false
        },
        1000: {
          items: 4,
          nav: true,
          loop: true
        }
      }
    });
  </script>
<script src="bootstrap/bootstrap.bundle.min.js"></script>
  <?php include "include/footer.php" ?>


</body>

</html>
<?php
include "db.php";
$obj = new database();



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include "include/link.php" ?>
</head>

<body>
    <?php include "include/nav.php" ?>


    <div class="container">
        <div class="row mb-3">
            <h4 class="text-center mt-5">Our Clients & Partnerships</h4>


            <?php
            $tbl = 'partner';

            $obj->select_data($tbl);
            $arr =  $obj->getResult();

            foreach ($arr as $value => $v) { ?>


                <div class="col-lg-3 col-md-6  my-2 d-flex   justify-content-center  text-center  ">

                    <div class="shadow text-center   p-3 " style="width: 200px;
    height: 200px;
    object-fit: contain;
    display: grid;
    place-items: center;">
                        <img src="./admin/img/<?php echo $v['img']; ?>" width="100%" alt="">
                    </div>
                </div>


            <?php } ?>
        </div>
    </div>



    <?php include "include/footer.php" ?>

</body>

</html>
<?php
include "db.php";
$obj = new database();  
?>





<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include "include/link.php" ?>
</head>

<body>
    <?php include "include/nav.php" ?>


    <div class="container-fluid">
        <div class="row ">
            <div class="col-lg-12 g-0">
                <img src="./allimages/2.jpg" width="100%" height="307px" alt="">
                <div class="container">
                    <div class="row justify-content-center mb-5">
                        <?php
                        $tbl = 'video';
                        // $id = $_GET['id'];
                        
                        $obj->select_data($tbl);

                        $arr =  $obj->getResult();

                        foreach ($arr as $value => $v) { ?>
                            <div class="col-lg-6 mt-5">
                                <div class="card border-0 shadow rounded-0">
                                    <video src="./admin/img/<?php echo $v['img'] ?>" autoplay  loop muted width="100%"></video>
                                </div>
                            </div>

                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include "include/footer.php" ?>

</body>

</html>